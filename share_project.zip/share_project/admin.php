<?php
session_start();
include("users.php");

if (!isset($_SESSION["user"]) || $_SESSION["role"] !== "admin") {
    die("صلاحية غير كافية.");
}

$file = 'users.php';
$msg = "";

// ✅ إضافة مستخدم
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["new_user"])) {
    $newUser = $_POST["new_user"];
    $newPass = $_POST["new_pass"];

    // منع إضافة مستخدم مكرر
    if (isset($users[$newUser])) {
        $msg = "⚠️ المستخدم موجود مسبقاً.";
    } else {
        $data = file_get_contents($file);
        $insert = "\n    \"$newUser\" => [\"pass\" => \"$newPass\", \"role\" => \"user\"],";
        $data = preg_replace('/\[(.*?)\];/s', "[$1,$insert\n];", $data);
        file_put_contents($file, $data);
        $msg = "✅ تمت إضافة المستخدم '$newUser' بنجاح.";
    }
}

// ❌ حذف مستخدم
if (isset($_GET["delete"])) {
    $deleteUser = $_GET["delete"];
    if ($deleteUser === $_SESSION["user"]) {
        $msg = "❌ لا يمكنك حذف نفسك كأدمن.";
    } elseif (isset($users[$deleteUser])) {
        unset($users[$deleteUser]);
        $newContent = "<?php\n\$users = [\n";
        foreach ($users as $u => $info) {
            $pass = $info["pass"];
            $role = $info["role"];
            $newContent .= "    \"$u\" => [\"pass\" => \"$pass\", \"role\" => \"$role\"],\n";
        }
        $newContent .= "];\n?>";
        file_put_contents($file, $newContent);
        $msg = "🗑️ تم حذف المستخدم '$deleteUser'.";
        // تحديث البيانات
        include("users.php");
    }
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>لوحة تحكم الأدمن</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>👑 لوحة تحكم الأدمن</h1>
    <p><a href="index.php">⬅️ رجوع</a></p>

    <?php if ($msg) echo "<p style='color:green;'>$msg</p>"; ?>

    <h3>➕ إضافة مستخدم</h3>
    <form method="post">
        <label>اسم المستخدم الجديد:</label>
        <input type="text" name="new_user" required>
        <label>كلمة المرور:</label>
        <input type="text" name="new_pass" required>
        <button type="submit">إضافة</button>
    </form>

    <hr>

    <h3>🧑‍💼 قائمة المستخدمين</h3>
    <table border="1" width="100%" cellpadding="8">
        <tr style="background:#f0f0f0;">
            <th>اسم المستخدم</th>
            <th>الدور</th>
            <th>إجراء</th>
        </tr>
        <?php foreach ($users as $u => $info): ?>
            <?php if ($u !== $_SESSION["user"]): ?>
                <tr>
                    <td><?= htmlspecialchars($u) ?></td>
                    <td><?= $info["role"] ?></td>
                    <td>
                        <a href="admin.php?delete=<?= urlencode($u) ?>" onclick="return confirm('هل أنت متأكد من حذف المستخدم <?= $u ?>؟');">🗑️ حذف</a>
                    </td>
                </tr>
            <?php endif; ?>
        <?php endforeach; ?>
    </table>
</div>
</body>
</html>
