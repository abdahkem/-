<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit;
}

if (!isset($_GET["file"])) {
    die("لم يتم تحديد ملف للتحميل.");
}

$filename = basename($_GET["file"]);
$filepath = "uploads/" . $filename;

if (!file_exists($filepath)) {
    die("الملف غير موجود.");
}

// تأكد أن المستخدم إما هو المرسل أو المستلم
$user = $_SESSION["user"];
if (strpos($filename, $user . "_to_") !== 0 && strpos($filename, "_to_" . $user) === false) {
    die("لا تملك صلاحية تحميل هذا الملف.");
}

header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . filesize($filepath));
readfile($filepath);
exit;
?>
