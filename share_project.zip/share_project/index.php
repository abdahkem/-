<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit;
}

include("users.php");

$username = $_SESSION["user"];
$role = $_SESSION["role"];
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>مشاركة الملفات</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>مرحباً <?= htmlspecialchars($username) ?> 👋</h1>
    <p class="logout-link">
        <a href="logout.php">🚪 تسجيل الخروج</a>
        <?php if ($role === "admin"): ?>
            | <a href="admin.php">⚙️ لوحة تحكم الأدمن</a>
        <?php endif; ?>
    </p>

    <h2>📤 رفع ملف</h2>
    <form action="upload.php" method="post" enctype="multipart/form-data">
        <label>أرسل إلى:</label>
        <select name="to_user" required>
            <option value="">-- اختر المستخدم --</option>
            <?php
            foreach ($users as $user => $data) {
                if ($user !== $username) {
                    echo "<option value=\"$user\">$user</option>";
                }
            }
            ?>
        </select>
        <input type="file" name="file" required>
        <button type="submit">رفع</button>
    </form>

    <h2>📂 الملفات المستلمة</h2>
    <ul>
        <?php
        $files = scandir("uploads");
        $found = false;
        foreach ($files as $file) {
            if (strpos($file, "_to_$username") !== false) {
                $found = true;
                echo "<li>
                        $file 
                        <a href='uploads/$file' target='_blank'>عرض</a> | 
                        <a href='download.php?file=$file'>تحميل</a> | 
                        <a href='uploads/$file' target='_blank' onclick=\"window.open(this.href, '_blank'); setTimeout(() => { window.print(); }, 500); return false;\">🖨️ طباعة</a>
                      </li>";
            }
        }
        if (!$found) {
            echo "<li>لا توجد ملفات مستلمة بعد.</li>";
        }
        ?>
    </ul>

    <h2>📤 الملفات التي أرسلتها</h2>
    <ul>
        <?php
        $found = false;
        foreach ($files as $file) {
            if (strpos($file, $username . "_to_") === 0) {
                $found = true;
                echo "<li>
                        $file 
                        <a href='uploads/$file' target='_blank'>عرض</a> | 
                        <a href='download.php?file=$file'>تحميل</a> | 
<a href='print.php?file=<?= urlencode($file) ?>' target='_blank'>🖨️ طباعة</a>
                      </li>";
            }
        }
        if (!$found) {
            echo "<li>لا توجد ملفات مرسلة بعد.</li>";
        }
        ?>
    </ul>
</div>
</body>
</html>
