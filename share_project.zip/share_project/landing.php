<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>ملفاتي | نظام مشاركة الملفات</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background: linear-gradient(to right, #74ebd5, #ACB6E5);
            color: #fff;
            font-family: 'Cairo', sans-serif;
            text-align: center;
            padding: 60px 20px;
        }

        .landing-container {
            max-width: 600px;
            margin: auto;
            background: rgba(255, 255, 255, 0.1);
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 8px 30px rgba(0,0,0,0.1);
        }

        h1 {
            font-size: 42px;
            margin-bottom: 20px;
        }

        p {
            font-size: 18px;
            margin-bottom: 40px;
        }

        .btn-login {
            padding: 12px 30px;
            background: #fff;
            color: #3498db;
            border: none;
            font-size: 18px;
            border-radius: 6px;
            cursor: pointer;
            transition: 0.3s;
            text-decoration: none;
        }

        .btn-login:hover {
            background: #ecf0f1;
        }
    </style>
</head>
<body>

    <div class="landing-container">
        <h1>📁 ملفــاتي</h1>
        <p>نظام بسيط وآمن لمشاركة الملفات والطباعة بين زملاء العمل أو الدراسة.</p>
        <a href="login.php" class="btn-login">دخول إلى النظام</a>
    </div>

</body>
</html>
