<?php
session_start();
include("users.php");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];

    if (isset($users[$username]) && $users[$username]["pass"] === $password) {
        $_SESSION["user"] = $username;
        $_SESSION["role"] = $users[$username]["role"];
        header("Location: index.php");
        exit;
    } else {
        $error = "❌ اسم المستخدم أو كلمة المرور غير صحيحة.";
    }
}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>تسجيل الدخول</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>🔐 تسجيل الدخول</h1>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
    <form method="post">
        <label>اسم المستخدم:</label>
        <input type="text" name="username" required>

        <label>كلمة المرور:</label>
        <input type="password" name="password" required>

        <button type="submit">دخول</button>
    </form>
</div>
</body>
</html>
