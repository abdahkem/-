<?php
if (!isset($_GET["file"])) {
    die("لم يتم تحديد الملف.");
}

$file = basename($_GET["file"]);
$path = "uploads/" . $file;

$ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));

// نسمح فقط بالأنواع القابلة للطباعة
$printable = ['pdf', 'png', 'jpg', 'jpeg', 'gif', 'txt'];

if (!in_array($ext, $printable)) {
    die("❌ هذا النوع من الملفات لا يمكن طباعته تلقائياً.");
}

?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <title>طباعة الملف</title>
    <style>
        body { margin: 0; }
        iframe {
            width: 100vw;
            height: 100vh;
            border: none;
        }
    </style>
</head>
<body>
<iframe src="<?= $path ?>" onload="this.contentWindow.focus(); this.contentWindow.print();"></iframe>
</body>
</html>
