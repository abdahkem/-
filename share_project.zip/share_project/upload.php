<?php
session_start();
if (!isset($_SESSION["user"])) {
    header("Location: login.php");
    exit;
}

$from = $_SESSION["user"];
$to = $_POST["to_user"];

if (!isset($_FILES["file"])) {
    die("لم يتم اختيار ملف.");
}

$fileError = $_FILES["file"]["error"];
if ($fileError !== UPLOAD_ERR_OK) {
    die("حدث خطأ أثناء رفع الملف. رمز الخطأ: $fileError");
}

$target_dir = "uploads/";
if (!is_dir($target_dir)) {
    mkdir($target_dir, 0777, true);
}

$original_name = basename($_FILES["file"]["name"]);
$new_name = $from . "_to_" . $to . "_" . time() . "_" . $original_name;
$target_file = $target_dir . $new_name;

if (!move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
    die("فشل في نقل الملف إلى مجلد الرفع.");
}

header("Location: index.php");
exit;
?>
