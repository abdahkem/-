<?php
$users = [
    "ahmed" => ["pass" => "1234", "role" => "admin"],
    "ali"   => ["pass" => "5678", "role" => "user"]
];
?>
